#!/bin/sh
echo $VAR
VAR=b
echo $VAR
ps w
