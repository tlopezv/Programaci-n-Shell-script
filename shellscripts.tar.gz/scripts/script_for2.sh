#!/bin/sh
for file in `ls /home/dit`; do
   echo "Fichero: $file"
done