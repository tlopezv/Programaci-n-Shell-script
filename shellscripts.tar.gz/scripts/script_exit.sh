echo Dentro del script
exit 3
echo Fuera del script 
