#!/bin/sh
for VAR in 0 1 2 3
do
   echo $VAR
done 
