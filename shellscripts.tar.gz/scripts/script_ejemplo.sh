#!/bin/dash
# Esto no se interpreta
echo Hola
ps w
echo "Proceso lee el script: $$" 
