#!/bin/bash
export VAR=a
echo $VAR
ps w
./script_hijo.sh
echo $VAR 
