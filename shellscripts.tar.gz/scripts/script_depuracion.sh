#!/bin/sh
echo Hola
if true; then
    echo hola2
    ls /
fi 