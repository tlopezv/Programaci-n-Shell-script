#!/bin/sh
for i in `seq 1 3`; do
   echo "Iteracion: $i"
done