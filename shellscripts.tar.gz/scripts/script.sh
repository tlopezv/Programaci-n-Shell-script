echo "Contenido carpeta personal de dit:"
ls /home/dit/
