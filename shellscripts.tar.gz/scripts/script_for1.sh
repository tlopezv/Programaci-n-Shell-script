#!/bin/sh
for i in 1 2 3; do
   echo "Iteracion: $i"
done > ficherosalida
