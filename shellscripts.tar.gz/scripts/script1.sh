#!/bin/bash
VAR=a
echo $VAR
ps w
. script2.sh
echo $VAR 
